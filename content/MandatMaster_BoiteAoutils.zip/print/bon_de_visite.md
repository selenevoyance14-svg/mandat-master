# Bon de Visite

**RÉFÉRENCE DU MANDAT :** [Numéro]
**BIEN CONCERNÉ :** [Adresse complète du bien]

---

**Le soussigné(e) :**

Nom : ...............................................
Prénom : ............................................
Adresse : ...........................................
Tél : ...............................................
Email : .............................................

Reconnaît avoir visité ce jour, par l'intermédiaire de l'Agence [Nom Agence] / Mandataire [Votre Nom], les biens immobiliers désignés ci-dessus.

Le présent bon de visite a pour but de constater la présentation par nos soins des biens visités.

Le soussigné s'interdit en conséquence de traiter l'achat de ces biens, directement ou indirectement, par l'intermédiaire d'une autre agence ou d'un autre intermédiaire, sans le concours de l'Agence [Nom Agence] / Mandataire [Votre Nom], et ce, pendant une durée de **[Durée] mois** à compter de ce jour.
En cas de violation de cet engagement, il s'exposera au paiement de dommages-intérêts égaux au montant de la commission prévue au mandat.

Fait à ......................................... le .........................................

**Signature du Visiteur :**
(Précédée de la mention "Lu et approuvé - Bon pour visite")

.........................................
.........................................

**Signature de l'Agent :**

.........................................
